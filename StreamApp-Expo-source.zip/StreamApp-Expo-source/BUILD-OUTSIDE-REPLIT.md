# StreamApp — standalone Expo source

This archive contains the self-contained Expo source for StreamApp, including the Android EAS configuration and web/PWA files.

## Android APK

Install the dependencies in this directory, connect the project to your EAS account, and start an EAS Build using the `preview` profile from `eas.json`. That profile is configured to output an installable APK.

The Android application ID is `com.streamapp.app`.

## Web/PWA

The web export script is available as `build:web` and writes the host-ready site to `web-dist/`. Deploy that folder to Vercel or Netlify over HTTPS for Chrome installation support.
